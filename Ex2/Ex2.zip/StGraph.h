#ifndef STGRAPH_H
#define STGRAPH_H

#include "Station.h"
#include <fstream>
#include <string>
#include <iterator>
#include <algorithm>
#include <vector>

class StGraph
{
private:
    vector<Station> graph;
public:
    StGraph(/* args */);
    ~StGraph();
    bool load(string fileName);
    bool isExist(string startSt, string endSt);
    Station *find(string startSt);
};

#endif