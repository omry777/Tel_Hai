#include "Station.h"


size_t Station::findDest(string endStation, TransportType type){
    auto releventGraph = dests.find(type);
    for (size_t i = 0; i < releventGraph->second.size(); i++)
        if (releventGraph->second[i]->name.compare(endStation))
            return it;
    
    return nullptr;
}