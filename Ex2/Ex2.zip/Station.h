#ifndef STATION_H
#define STATION_H

#include <iostream>
#include <set>
#include <map>
#include <string>

using namespace std;

typedef enum TransportType {Bus=1, Trum=2, Sprinter=3, Rail=5};
typedef enum StationType {Central = 10, Intercity = 15, Stad = 5};

class Station
{
private:
    string name;
    StationType type;
    map<TransportType, map<Station *,int>> dests;
    friend class StGraph;
public:
    Station(string name, StationType t);
    map<Station*, int >::iterator *findDest(string, TransportType);
    ~Station();

    
    
};

Station::Station(string n, StationType t)
{
    name = n;
    type = t;
    dests = map<TransportType, map<Station *,int>>();
}

Station::~Station()
{
}


#endif