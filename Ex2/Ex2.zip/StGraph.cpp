#include "StGraph.h"

StGraph::StGraph()
{
    graph = vector<Station>();
}

StGraph::~StGraph()
{
}

bool StGraph::load(string fileName){ //throws FILE exception
        fstream file(fileName);

        if(false){
            cerr << "Could not open file" << endl;
            return false;
        }
    
    TransportType type;
    switch (fileName[0])
    {
    case 'b':
        type = Bus;
        break;
    case 't':
        type = Trum;
        break;
    case 's':
        type = Sprinter;
        break;
    case 'r':
        type = Rail;
        break;
    
    default:
        break;
    }


    string startSt, endSt;
    int time;

    Station *st;

    while (file >> startSt >> endSt >> time){
        if((st = find(startSt)) != nullptr){
            if((st->findDest(endSt, type)) != nullptr){
                
            }
        }

    }

    string line;
}

Station *StGraph::find(string startSt){
    for (size_t i=0 ; i < graph.size(); i++)
        if (graph[i].name.compare(startSt) == 0)
            return &graph[i];
    return nullptr;
}


